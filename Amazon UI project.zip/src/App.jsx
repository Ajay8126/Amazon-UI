 import React, { useState, useEffect, createContext, useContext, useReducer } from "react";

// ----- Global State -----
const Store = createContext();

const initialState = {
  page: "home", // home, detail, cart, checkout, login
  cart: [],
  user: null,
  selectedProduct: null,
};

function reducer(state, action) {
  switch (action.type) {
    case "SET_PAGE":
      return { ...state, page: action.payload };
    case "SELECT_PRODUCT":
      return { ...state, selectedProduct: action.payload };
    case "ADD_TO_CART":
      return { ...state, cart: [...state.cart, action.payload] };
    case "REMOVE_FROM_CART":
      return { ...state, cart: state.cart.filter(p => p.id !== action.payload) };
    case "SET_USER":
      return { ...state, user: action.payload };
    default:
      return state;
  }
}

function StoreProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  return <Store.Provider value={{ state, dispatch }}>{children}</Store.Provider>;
}

function useStore() {
  return useContext(Store);
}

// ----- Sample Products -----
const products = [
  { id: 1, title: "Laptop", price: 999, rating: 4, description: "High performance laptop", image: "https://via.placeholder.com/200" },
  { id: 2, title: "Phone", price: 599, rating: 5, description: "Smartphone with camera", image: "https://via.placeholder.com/200" },
  { id: 3, title: "Headphones", price: 199, rating: 3, description: "Noise cancelling", image: "https://via.placeholder.com/200" },
];

// ----- Components -----
function Header() {
  const { state, dispatch } = useStore();
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: 10, background: "#f3f3f3" }}>
      <h2 style={{ cursor: "pointer" }} onClick={() => dispatch({ type: "SET_PAGE", payload: "home" })}>Amazon Clone</h2>
      <div>
        {state.user ? (
          <span>Hello, {state.user} | <button onClick={() => dispatch({ type: "SET_PAGE", payload: "login" })}>Logout</button></span>
        ) : (
          <button onClick={() => dispatch({ type: "SET_PAGE", payload: "login" })}>Login</button>
        )}
        <button style={{ marginLeft: 10 }} onClick={() => dispatch({ type: "SET_PAGE", payload: "cart" })}>Cart ({state.cart.length})</button>
      </div>
    </div>
  );
}

function ProductCard({ product }) {
  const { dispatch } = useStore();
  return (
    <div style={{ border: "1px solid #ccc", padding: 10, margin: 10, width: 200 }}>
      <img src={product.image} alt={product.title} style={{ width: "100%" }} />
      <h3>{product.title}</h3>
      <p>${product.price}</p>
      <p>⭐ {product.rating}</p>
      <button onClick={() => { dispatch({ type: "SELECT_PRODUCT", payload: product }); dispatch({ type: "SET_PAGE", payload: "detail" }); }}>View</button>
    </div>
  );
}

// ----- Pages -----
function Home() {
  return (
    <div style={{ display: "flex", flexWrap: "wrap" }}>
      {products.map(p => <ProductCard key={p.id} product={p} />)}
    </div>
  );
}

function ProductDetail() {
  const { state, dispatch } = useStore();
  const product = state.selectedProduct;
  if (!product) return <p>No product selected</p>;

  return (
    <div style={{ padding: 20 }}>
      <img src={product.image} style={{ width: 300 }} />
      <h2>{product.title}</h2>
      <p>${product.price}</p>
      <p>⭐ {product.rating}</p>
      <p>{product.description}</p>
      <button onClick={() => dispatch({ type: "ADD_TO_CART", payload: product })}>Add to Cart</button>
      <button style={{ marginLeft: 10 }} onClick={() => dispatch({ type: "SET_PAGE", payload: "home" })}>Back</button>
    </div>
  );
}

function Cart() {
  const { state, dispatch } = useStore();
  const total = state.cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div style={{ padding: 20 }}>
      <h2>Cart</h2>
      {state.cart.length === 0 ? <p>Cart is empty</p> : (
        <div>
          {state.cart.map(item => (
            <div key={item.id} style={{ marginBottom: 10 }}>
              {item.title} - ${item.price} 
              <button onClick={() => dispatch({ type: "REMOVE_FROM_CART", payload: item.id })} style={{ marginLeft: 10 }}>Remove</button>
            </div>
          ))}
          <h3>Total: ${total}</h3>
          <button onClick={() => dispatch({ type: "SET_PAGE", payload: "checkout" })}>Checkout</button>
        </div>
      )}
      <button onClick={() => dispatch({ type: "SET_PAGE", payload: "home" })} style={{ marginTop: 10 }}>Back to Home</button>
    </div>
  );
}

function Checkout() {
  const { state, dispatch } = useStore();
  const total = state.cart.reduce((sum, item) => sum + item.price, 0);
  return (
    <div style={{ padding: 20 }}>
      <h2>Checkout</h2>
      <p>Total Amount: ${total}</p>
      <form>
        <input placeholder="Name" required /><br/><br/>
        <input placeholder="Address" required /><br/><br/>
        <input placeholder="City" required /><br/><br/>
        <button type="submit">Place Order</button>
      </form>
      <button onClick={() => dispatch({ type: "SET_PAGE", payload: "cart" })} style={{ marginTop: 10 }}>Back to Cart</button>
    </div>
  );
}

function Login() {
  const { dispatch } = useStore();
  const [name, setName] = useState("");
  const handleLogin = () => {
    dispatch({ type: "SET_USER", payload: name });
    dispatch({ type: "SET_PAGE", payload: "home" });
  };
  return (
    <div style={{ padding: 20 }}>
      <h2>Login</h2>
      <input value={name} onChange={e => setName(e.target.value)} placeholder="Enter name" />
      <button onClick={handleLogin} style={{ marginLeft: 10 }}>Login</button>
    </div>
  );
}

// ----- Main App -----
function App() {
  const { state } = useStore();
  return (
    <div>
      <Header />
      {state.page === "home" && <Home />}
      {state.page === "detail" && <ProductDetail />}
      {state.page === "cart" && <Cart />}
      {state.page === "checkout" && <Checkout />}
      {state.page === "login" && <Login />}
    </div>
  );
}

export default function Root() {
  return <StoreProvider><App /></StoreProvider>;
}
